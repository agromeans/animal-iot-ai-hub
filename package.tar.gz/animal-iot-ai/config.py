from configparser import ConfigParser
from lib.logger_opt import *

config_file = './config.ini'
config = ConfigParser()
config.read(config_file)

version = ''

path_yolo_model_cfg = ''
path_yolo_model_weights = ''
path_yolo_model_names = ''


api_upload_record = ''

def get_version():
    return version

def check_config_section():
    if not config.has_section('common'):
        config.add_section('common')

    if not config.has_section('path'):
        config.add_section('path')

    if not config.has_section('api'):
        config.add_section('api')

    config.write(open(config_file, 'w'))

def get_config():
    global version, path_yolo_model_cfg, path_yolo_model_weights, path_yolo_model_names, \
        api_upload_record

    try:
        version = config.get('common', 'version')
    except Exception as e:
        logger.warning(e)
        version = ''

    try:
        path_yolo_model_cfg = config.get('path', 'yolo_model_cfg')
    except Exception as e:
        logger.warning(e)
        path_yolo_model_cfg = ''

    try:
        path_yolo_model_weights = config.get('path', 'yolo_model_weights')
    except Exception as e:
        logger.warning(e)
        path_yolo_model_weights = ''

    try:
        path_yolo_model_names = config.get('path', 'yolo_model_names')
    except Exception as e:
        logger.warning(e)
        path_yolo_model_names = ''

    try:
        api_upload_record = config.get('api', 'upload_record')
    except Exception as e:
        logger.warning(e)
        api_upload_record = ''
            
def reload_config():
    check_config_section()
    get_config()

if __name__ == '__main__':
    reload_config()
