# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify
import config
import argparse
import cv2
import numpy as np
import lib.opt as opt
import lib.utils as utils
from lib.logger_opt import logger
from lib.exception_opt import ExceptionCommon
import base64


app = Flask(__name__)

@app.before_request
def before_request():
    logger.info("'{path}' start serving remote ip: {ip}".format(path=request.path, ip=request.remote_addr))
    
@app.route('/predict', methods=['POST'])
def predict():
    try:
        jpeg_as_text = request.files['image'].read()
        jpeg = base64.b64decode(jpeg_as_text)
        np_array = np.frombuffer(jpeg, np.uint8)
        image = cv2.imdecode(np_array, cv2.IMREAD_UNCHANGED)
        
        conf_thresh = float(request.files['conf_thresh'].read().decode('ascii'))
        nms_thresh = float(request.files['nms_thresh'].read().decode('ascii'))
        input_size = int(request.files['input_size'].read().decode('ascii'))
        
        fov = request.files.get('fov')
        fov = 0.5 if fov is None else float(fov.read().decode('ascii'))
        output_shape_width = request.files.get('output_shape_width')
        output_shape_width = image.shape[1] if output_shape_width is None else int(output_shape_width.read().decode('ascii'))
        output_shape_height = request.files.get('output_shape_height')
        output_shape_height = image.shape[0] if output_shape_height is None else int(output_shape_height.read().decode('ascii'))
        output_shape = (output_shape_height, output_shape_width)
    except Exception as e:
        raise ExceptionCommon(message='error in request from client.' + str(e))
        
    try:
        ai_engine = opt.AiEngine(input_size)
        main_cat, main_cat_bboxes, others_cat_bboxes = ai_engine.predict(image, conf_thresh, nms_thresh, fov, output_shape)
    except Exception as e:
        raise ExceptionCommon(message='error in ai predict.' + str(e))
        
    ai_record = utils.ai_record_formatting(main_cat, main_cat_bboxes, others_cat_bboxes)
    response = dict(status_code=200, message=ai_record)
    
    return jsonify(response), 200
    
@app.route("/version")
def get_version():
    return config.version
    
@app.errorhandler(ExceptionCommon)
def handle_invalid_usage(error):
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response
    
@app.errorhandler(404)
def page_not_found(error):
    response = dict(status_code=404, message="404 Not Found")
    return jsonify(response), 404
    
@app.errorhandler(500)
def handle_500(error):
    response = dict(status_code=500, message="500 Error")
    return jsonify(response), 500
    
    
if __name__ == "__main__":
    config.reload_config()
    parse = argparse.ArgumentParser()
    parse.add_argument('-v', '--version', action='version', version=config.get_version(), help='Display version')
    parse.parse_args()
    logger.info('====The program is starting====')
    app.run(host='0.0.0.0', port=5080, threaded=False)
    